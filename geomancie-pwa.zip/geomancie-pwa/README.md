# Géomancie · ʿilm al-raml — Application PWA

Application web installable (PWA) : consultation géomantique complète (tracé des figures,
thème, numérologie, tarot, verset, talisman, heure planétaire, sacrifice associé).
Fonctionne hors ligne une fois installée.

## Contenu du dossier

```
index.html      → l'application (page unique, autonome)
manifest.json   → nom, icônes, couleurs de l'app installée
sw.js           → service worker (mise en cache hors ligne)
icons/          → icônes 192px, 512px et 512px « maskable »
```

## 1. Créer le dépôt GitHub

Sur github.com, cliquez sur **New repository**, donnez-lui un nom (par exemple
`geomancie`), laissez-le public, ne cochez aucune case d'initialisation, puis
**Create repository**.

## 2. Pousser ces fichiers

Sur votre ordinateur, dans un terminal, à l'intérieur de ce dossier :

```bash
git init
git add .
git commit -m "Application géomancie (PWA)"
git branch -M main
git remote add origin https://github.com/VOTRE-COMPTE/geomancie.git
git push -u origin main
```

Remplacez `VOTRE-COMPTE` par votre nom d'utilisateur GitHub. Si Git vous
demande de vous authentifier, utilisez un **token d'accès personnel** (GitHub
n'accepte plus les mots de passe en ligne de commande) : Settings →
Developer settings → Personal access tokens → Generate new token, avec la
permission `repo`.

## 3. Activer GitHub Pages

Dans le dépôt sur GitHub : **Settings → Pages**. Sous « Build and
deployment », choisissez **Deploy from a branch**, branche **main**, dossier
**/ (root)**, puis **Save**.

Au bout d'une à deux minutes, votre application est en ligne à l'adresse :

```
https://VOTRE-COMPTE.github.io/geomancie/
```

## 4. Installer l'application

- **Android (Chrome)** : ouvrez le lien, menu ⋮ → « Installer l'application ».
- **iPhone/iPad (Safari)** : ouvrez le lien, bouton Partager → « Sur l'écran
  d'accueil ».
- **Ordinateur (Chrome/Edge)** : icône d'installation dans la barre
  d'adresse, ou menu ⋮ → « Installer ».

L'application fonctionne ensuite hors connexion, avec sa propre icône sur
l'écran d'accueil.

## Mettre à jour l'application plus tard

Après une modification de `index.html`, `manifest.json` ou `sw.js` :

```bash
git add .
git commit -m "Mise à jour"
git push
```

GitHub Pages republie automatiquement en une à deux minutes. Si une personne
a déjà installé l'app, la nouvelle version se charge au prochain lancement
(le service worker se renouvelle tout seul).
